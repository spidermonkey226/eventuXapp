export interface Permision {
  id: number;
  permisionName: string;
  role: string;
  name: string;
}
