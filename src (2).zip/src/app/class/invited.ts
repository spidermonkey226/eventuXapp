export class Invited {
  id: {
    eventId: number;
    email: string;
  };
  firstName: string;
  event: {
    eventId: number;
    name: string;
  };
  coming?: boolean; 

  constructor(
    firstName: string,
    event: { eventId: number; name: string },
    id: { eventId: number; email: string },
    coming?: boolean
  ) {
    this.firstName = firstName;
    this.event = event;
    this.id = id;
    this.coming = coming;
  }
}