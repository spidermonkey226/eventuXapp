import { Component,OnInit  } from '@angular/core';
import { CommonModule } from '@angular/common'; // Import CommonModule
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router'; // ✅ CORRECT
import { jwtDecode } from 'jwt-decode'; // ✅ Correct
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterModule,CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit {
  isLoggedIn: boolean = false;
  userEmail: string | null = null;

   constructor(private router: Router, private authService: AuthService) {}

  ngOnInit(): void {
    this.authService.isLoggedIn$.subscribe((status) => {
      this.isLoggedIn = status;
    });

    const token = localStorage.getItem('token');
    if (token) {
      try {
        const decoded: any = jwtDecode(token);
        this.userEmail = decoded.sub;
      } catch (error) {
        console.error("Invalid token");
      }
    }
  }

  logout(): void {
    this.authService.logout(); // ✅ call logout from service
    this.userEmail = null;
    this.router.navigate(['/']);
  }
}