import { Injectable } from '@angular/core';
import { Event } from '@angular/router';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable,throwError } from 'rxjs';
import { map } from 'rxjs';
import { EventModel } from '../class/event';

@Injectable({
  providedIn: 'root'
})
export class EventsService {
  private url: string = "http://localhost:3000/events";
  private headers = { "content-type": "application/json" };
  Events: Event[] = []
  constructor(private http: HttpClient) {}

  // קבלת כל האירועים
  getEvents(): Observable<EventModel[]> {
    return this.http.get<EventModel[]>(this.url);
  }

  // הוספת אירוע חדש
  addEvent(newEvent: EventModel): Observable<string> {
    return this.getEvents().pipe(
      map((events) => {
        newEvent.id = events.length + 1; // יצירת מזהה חדש
        this.http.post(this.url, newEvent, { headers: this.headers }).subscribe();
        return 'Event created successfully!';
      })
    );
  }

  // קבלת אירוע לפי ID
  getEventById(id: number): Observable<EventModel | undefined> {
    return this.http.get<EventModel>(`${this.url}/${id}`);
  }

  // מחיקת אירוע
  deleteEvent(id: number): Observable<void> {
    return this.http.delete<void>(`${this.url}/${id}`);
  }

  // עדכון אירוע
  updateEvent(updatedEvent: EventModel): Observable<EventModel> {
    return this.http.put<EventModel>(`${this.url}/${updatedEvent.id}`, updatedEvent, {
      headers: this.headers
    });
  }

}
