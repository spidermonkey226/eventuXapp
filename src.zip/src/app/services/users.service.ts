import { Injectable } from '@angular/core';
import { User } from '../class/user';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable,throwError } from 'rxjs';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  url : string = "http://localhost:3000/users"
  headers = {"content-type" : "application/json"}
  users: User[] = []
  constructor(private http: HttpClient) {}

  // Fetch all users
  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(this.url);
  }

  // Register a new user
  registerUser(newUser: User): Observable<string> {
    return this.getUsers().pipe(
      map((users) => {
        const exists = users.some((user) => user.email === newUser.email);
        if (exists) {
          return 'User already exists!';
        } else {
          newUser.id = users.length + 1; // Assign new ID
          this.http.post(this.url, newUser, { headers: this.headers }).subscribe();
          return 'Registration successful!';
        }
      })
    );
  }
  

  // **Fixed Login Function (Efficient Querying)**
  login(email: string, password: string): Observable<User | null> {
    return this.http.get<User[]>(`${this.url}?email=${email}&password=${password}`).pipe(
      map((users) => {
        if (users.length > 0) {
          const user = users[0]; // Get the first matched user
          sessionStorage.setItem('loggedInUser', JSON.stringify(user)); // Store in session
          return user;
        }
        return null;
      })
    );
  }

  // Get logged-in user
  getLoggedInUser(): User | null {
    const user = sessionStorage.getItem('loggedInUser');
    return user ? JSON.parse(user) : null;
  }

  // Logout user
  logout(): void {
    sessionStorage.removeItem('loggedInUser');
    window.location.reload(); // Refresh navbar after logout
  }


}
