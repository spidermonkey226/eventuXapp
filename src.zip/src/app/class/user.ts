export type UserPermission = 'appadmin' | 'eventmanager' | 'eventhost' | 'regularuser';

export class User {
  id: number;
  fname: string;
  lname: string;
  email: string;
  phone: string;
  password: string;
  permission: UserPermission;
  date: Date;

  constructor(
    id: number,
    fname: string,
    lname: string,
    email: string,
    phone: string,
    password: string,
    permission: UserPermission,
    date: Date
  ) {
    this.id = id;
    this.fname = fname;
    this.lname = lname;
    this.email = email;
    this.phone = phone;
    this.password = password;
    this.permission = permission;
    this.date = date;
  }
}
