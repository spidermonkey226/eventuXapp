import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { User } from '../class/user';
import { UserService } from '../services/users.service';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  user: User = new User(0, '', '', '', '', '', 'regularuser', new Date());

  constructor(private userService: UserService) {}

  onSubmit(): void {
    this.user.date = new Date();

    this.userService.registerUser(this.user).subscribe((res) => {
      alert(res);
      if (res === 'Registration successful!') {
        this.user = new User(0, '', '', '', '', '', 'regularuser', new Date());
      }
    });
  }
}
